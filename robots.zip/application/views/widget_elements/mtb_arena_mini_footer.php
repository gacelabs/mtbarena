<div class="box-item zero-gap" style="background-color:transparent;border:0 none;">
	<div class="box-item-body" style="padding-top:0;">
		<p style="margin:0;"><a href="<?php echo base_url(); ?>" class="color-gray">MTB Arena</a> <small>&copy; <span class="year_today"></span></small></p>
		<ul class="spaced-list between">
			<li><a href="<?php echo base_url('terms'); ?>"><small class="color-gray">Terms</small></a></li>
			<li><a href="<?php echo base_url('privacy'); ?>"><small class="color-gray">Privacy</small></a></li>
			<li><a href=""><small class="color-gray">Contact</small></a></li>
		</ul>
	</div>
</div>

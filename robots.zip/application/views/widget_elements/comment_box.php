<div class="comment-box-parent">
	<div class="comment-box-item">
		<div class="media">
			<div class="media-left media-top">
				<img class="media-object" src="<?php echo base_url('assets/images/mtb/aeroic_tornado_x2.jpg') ?>">
			</div>
			<div class="media-body">
				<p class="media-heading"><b>Ema Margaret</b></p>
				<p class="zero-gap show-read-more">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. consequat.</p>
			</div>
		</div>
	</div>
	<div class="comment-box-item">
		<div class="media">
			<div class="media-left media-top">
				<img class="media-object" src="<?php echo base_url('assets/images/mtb/phantom_604.jpg') ?>">
			</div>
			<div class="media-body">
				<p class="media-heading"><b>Ava Francine</b></p>
				<p class="zero-gap show-read-more">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</div>
		</div>
	</div>
	<div class="comment-message-box-parent">
		<p><small>123 Comments</small></p>
		<div class="input-group">
			<textarea class="form-control custom-control" rows="1"></textarea>
			<span class="input-group-addon btn btn-info"><i class="fa fa-send"></i></span>
		</div>
	</div>
</div>
<div class="box-item">
	<div class="box-item-body-top">
		<p class="zero-gap color-theme"><b>Top Bike Shops</b></p>
	</div>
	<div class="box-item-body">
		<div class="table-responsive">
			<table class="table table-striped zero-gap">
				<thead>
					<tr>
						<th><small>#</small></th>
						<th><small>Shop Name</small></th>
						<th><small>Sale</small></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<th scope="row">1</th>
						<td><a href="">LJ Bikes Antipolo</a></td>
						<td>132</td>
					</tr>
					<tr>
						<th scope="row">2</th>
						<td><a href="">Skylark Bike Shop</a></td>
						<td>85</td>
					</tr>
					<tr>
						<th scope="row">3</th>
						<td><a href="">Glorious Bikes</a></td>
						<td>63</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
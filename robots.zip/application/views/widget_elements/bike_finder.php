<div class="box-item">
	<div class="box-item-body-top">
		<ul class="spaced-list between">
			<li>
				<p class="zero-gap color-theme"><b>Bike Finder</b></p>
			</li>
		</ul>
	</div>
	<div class="box-item-body">
		<div class="grid">
			<!-- LOOP here -->
			<div class="grid-item">
				<a href="<?php echo base_url('search/trinx'); ?>" style="text-decoration:none;"><p class="zero-gap">Trinx <small><kbd class="theme-kbd">123</kbd></small></p></a>
			</div>
			<!-- LOOP here -->
		</div>
	</div>
</div>

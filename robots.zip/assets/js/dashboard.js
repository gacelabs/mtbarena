$(document).ready(function() {
	$('.selectpicker').selectpicker();
});